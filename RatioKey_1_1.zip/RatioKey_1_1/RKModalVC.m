// File: RKModalVC.m
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import "RKModalVC.h"

UIAlertView *alert;

struct oneToOneFreq *tempOneToOne = NULL;

@implementation RKModalVC

@synthesize ppPicker;
@synthesize numeratorTF;
@synthesize denominatorTF;
@synthesize quotientTF;
@synthesize baseFreqTF;
@synthesize baseFreqXQuotientTF;
@synthesize mainTextLabel;
@synthesize secondTextLabel;
@synthesize ppPickerLabel;
@synthesize numeratorLabel;
@synthesize denominatorLabel;
@synthesize quotientLabel;
@synthesize baseFreqLabel;
@synthesize baseFreqXQuotientLabel;
@synthesize restoreDefaultsButton;
@synthesize cancelButton;
@synthesize applyButton;
@synthesize attackInitialLabel;
@synthesize attackInitialSlider;
@synthesize attackInitialTextField;
@synthesize attackDecayLabel;
@synthesize attackDecaySlider;
@synthesize attackDecayTextField;
@synthesize decaySustainLabel;
@synthesize decaySustainSlider;
@synthesize decaySustainTextField;
@synthesize sustainReleaseLabel;
@synthesize sustainReleaseSlider;
@synthesize sustainReleaseTextField;
@synthesize attackDurationLabel;
@synthesize attackDurationSlider;
@synthesize attackDurationTextField;
@synthesize decayDurationLabel;
@synthesize decayDurationSlider;
@synthesize decayDurationTextField;
@synthesize sustainDurationLabel;
@synthesize sustainDurationSlider;
@synthesize sustainDurationTextField;
@synthesize releaseDurationLabel;
@synthesize releaseDurationSlider;
@synthesize releaseDurationTextField;

CGRect ppPickerPortRect;
CGRect numeratorTFPortRect;
CGRect denominatorTFPortRect;
CGRect quotientTFPortRect;
CGRect baseFreqTFPortRect;
CGRect baseFreqXQuotientTFPortRect;
CGRect mainTextLabelPortRect;
CGRect secondTextLabelPortRect;
CGRect ppPickerLabelPortRect;
CGRect numeratorLabelPortRect;
CGRect denominatorLabelPortRect;
CGRect quotientLabelPortRect;
CGRect baseFreqLabelPortRect;
CGRect baseFreqXQuotientLabelPortRect;
CGRect restoreDefaultsButtonPortRect;
CGRect cancelButtonPortRect;
CGRect applyButtonPortRect;
CGRect attackInitialLabelPortRect;
CGRect attackInitialSliderPortRect;
CGRect attackInitialTextFieldPortRect;
CGRect attackDecayLabelPortRect;
CGRect attackDecaySliderPortRect;
CGRect attackDecayTextFieldPortRect;
CGRect decaySustainLabelPortRect;
CGRect decaySustainSliderPortRect;
CGRect decaySustainTextFieldPortRect;
CGRect sustainReleaseLabelPortRect;
CGRect sustainReleaseSliderPortRect;
CGRect sustainReleaseTextFieldPortRect;
CGRect attackDurationLabelPortRect;
CGRect attackDurationSliderPortRect;
CGRect attackDurationTextFieldPortRect;
CGRect decayDurationLabelPortRect;
CGRect decayDurationSliderPortRect;
CGRect decayDurationTextFieldPortRect;
CGRect sustainDurationLabelPortRect;
CGRect sustainDurationSliderPortRect;
CGRect sustainDurationTextFieldPortRect;
CGRect releaseDurationLabelPortRect;
CGRect releaseDurationSliderPortRect;
CGRect releaseDurationTextFieldPortRect;

CGRect ppPickerLandRect;
CGRect numeratorTFLandRect;
CGRect denominatorTFLandRect;
CGRect quotientTFLandRect;
CGRect baseFreqTFLandRect;
CGRect baseFreqXQuotientTFLandRect;
CGRect mainTextLabelLandRect;
CGRect secondTextLabelLandRect;
CGRect ppPickerLabelLandRect;
CGRect numeratorLabelLandRect;
CGRect denominatorLabelLandRect;
CGRect quotientLabelLandRect;
CGRect baseFreqLabelLandRect;
CGRect baseFreqXQuotientLabelLandRect;
CGRect restoreDefaultsButtonLandRect;
CGRect cancelButtonLandRect;
CGRect applyButtonLandRect;
CGRect attackInitialLabelLandRect;
CGRect attackInitialSliderLandRect;
CGRect attackInitialTextFieldLandRect;
CGRect attackDecayLabelLandRect;
CGRect attackDecaySliderLandRect;
CGRect attackDecayTextFieldLandRect;
CGRect decaySustainLabelLandRect;
CGRect decaySustainSliderLandRect;
CGRect decaySustainTextFieldLandRect;
CGRect sustainReleaseLabelLandRect;
CGRect sustainReleaseSliderLandRect;
CGRect sustainReleaseTextFieldLandRect;
CGRect attackDurationLabelLandRect;
CGRect attackDurationSliderLandRect;
CGRect attackDurationTextFieldLandRect;
CGRect decayDurationLabelLandRect;
CGRect decayDurationSliderLandRect;
CGRect decayDurationTextFieldLandRect;
CGRect sustainDurationLabelLandRect;
CGRect sustainDurationSliderLandRect;
CGRect sustainDurationTextFieldLandRect;
CGRect releaseDurationLabelLandRect;
CGRect releaseDurationSliderLandRect;
CGRect releaseDurationTextFieldLandRect;

- (void)viewDidLoad {
    [super viewDidLoad];
	ppPickerPortRect					= CGRectMake( 20.0, 207.0, 350.0, 216.0);
	numeratorTFPortRect					= CGRectMake( 20.0, 469.0, 350.0,  31.0);
	denominatorTFPortRect				= CGRectMake( 20.0, 508.0, 350.0,  31.0);
	quotientTFPortRect					= CGRectMake( 20.0, 615.0, 350.0,  31.0);
	baseFreqTFPortRect					= CGRectMake(398.0, 207.0, 350.0,  31.0);
	baseFreqXQuotientTFPortRect			= CGRectMake( 20.0, 697.0, 350.0,  31.0);
	mainTextLabelPortRect				= CGRectMake( 20.0,  20.0, 728.0, 149.0);
	secondTextLabelPortRect				= CGRectMake(398.0, 237.0, 350.0, 390.0);
	ppPickerLabelPortRect				= CGRectMake( 20.0, 178.0, 350.0,  21.0);
	numeratorLabelPortRect				= CGRectMake( 20.0, 443.0, 350.0,  21.0);
	denominatorLabelPortRect			= CGRectMake( 20.0, 542.0, 350.0,  21.0);
	quotientLabelPortRect				= CGRectMake( 20.0, 586.0, 350.0,  21.0);
	baseFreqLabelPortRect				= CGRectMake(398.0, 178.0, 350.0,  21.0);
	baseFreqXQuotientLabelPortRect		= CGRectMake( 20.0, 668.0, 350.0,  21.0);
	restoreDefaultsButtonPortRect		= CGRectMake(398.0, 646.0, 171.0,  37.0);
	cancelButtonPortRect				= CGRectMake(577.0, 646.0, 171.0,  37.0);
	applyButtonPortRect					= CGRectMake(398.0, 691.0, 350.0,  37.0);
	attackInitialLabelPortRect			= CGRectMake( 20.0, 752.0, 350.0,  21.0);
	attackInitialSliderPortRect			= CGRectMake( 18.0, 778.0, 249.0,  23.0);
	attackInitialTextFieldPortRect		= CGRectMake(273.0, 773.0,  97.0,  31.0);
	attackDecayLabelPortRect			= CGRectMake( 20.0, 812.0, 350.0,  21.0);
	attackDecaySliderPortRect			= CGRectMake( 18.0, 838.0, 249.0,  23.0);
	attackDecayTextFieldPortRect		= CGRectMake(273.0, 833.0,  97.0,  31.0);
	decaySustainLabelPortRect			= CGRectMake( 20.0, 872.0, 350.0,  21.0);
	decaySustainSliderPortRect			= CGRectMake( 18.0, 898.0, 249.0,  23.0);
	decaySustainTextFieldPortRect		= CGRectMake(273.0, 893.0,  97.0,  31.0);
	sustainReleaseLabelPortRect			= CGRectMake( 20.0, 932.0, 350.0,  21.0);
	sustainReleaseSliderPortRect		= CGRectMake( 18.0, 958.0, 249.0,  23.0);
	sustainReleaseTextFieldPortRect		= CGRectMake(273.0, 953.0,  97.0,  31.0);
	attackDurationLabelPortRect			= CGRectMake(398.0, 752.0, 350.0,  21.0);
	attackDurationSliderPortRect		= CGRectMake(396.0, 778.0, 249.0,  23.0);
	attackDurationTextFieldPortRect		= CGRectMake(651.0, 773.0,  97.0,  31.0);
	decayDurationLabelPortRect			= CGRectMake(398.0, 812.0, 350.0,  21.0);
	decayDurationSliderPortRect			= CGRectMake(396.0, 838.0, 249.0,  23.0);
	decayDurationTextFieldPortRect		= CGRectMake(651.0, 833.0,  97.0,  31.0);
	sustainDurationLabelPortRect		= CGRectMake(398.0, 872.0, 350.0,  21.0);
	sustainDurationSliderPortRect		= CGRectMake(396.0, 898.0, 249.0,  23.0);
	sustainDurationTextFieldPortRect	= CGRectMake(651.0, 893.0,  97.0,  31.0);
	releaseDurationLabelPortRect		= CGRectMake(398.0, 932.0, 350.0,  21.0);
	releaseDurationSliderPortRect		= CGRectMake(396.0, 958.0, 249.0,  23.0);
	releaseDurationTextFieldPortRect	= CGRectMake(651.0, 953.0,  97.0,  31.0);
	
	ppPickerLandRect					= CGRectMake( 20.0, 207.0, 350.0, 216.0);
	numeratorTFLandRect					= CGRectMake( 20.0, 469.0, 350.0,  31.0);
	denominatorTFLandRect				= CGRectMake( 20.0, 508.0, 350.0,  31.0);
	quotientTFLandRect					= CGRectMake( 20.0, 615.0, 350.0,  31.0);
	baseFreqTFLandRect					= CGRectMake(386.0, 207.0, 350.0,  31.0);
	baseFreqXQuotientTFLandRect			= CGRectMake( 20.0, 697.0, 350.0,  31.0);
	mainTextLabelLandRect				= CGRectMake( 20.0,  20.0, 720.0, 149.0);
	secondTextLabelLandRect				= CGRectMake(386.0, 237.0, 350.0, 390.0);
	ppPickerLabelLandRect				= CGRectMake( 20.0, 178.0, 350.0,  21.0);
	numeratorLabelLandRect				= CGRectMake( 20.0, 443.0, 350.0,  21.0);
	denominatorLabelLandRect			= CGRectMake( 20.0, 542.0, 350.0,  21.0);
	quotientLabelLandRect				= CGRectMake( 20.0, 586.0, 350.0,  21.0);
	baseFreqLabelLandRect				= CGRectMake(386.0, 178.0, 350.0,  21.0);
	baseFreqXQuotientLabelLandRect		= CGRectMake( 20.0, 668.0, 350.0,  21.0);
	restoreDefaultsButtonLandRect		= CGRectMake(386.0, 646.0, 171.0,  37.0);
	cancelButtonLandRect				= CGRectMake(565.0, 646.0, 171.0,  37.0);
	applyButtonLandRect					= CGRectMake(386.0, 691.0, 350.0,  37.0);
	attackInitialLabelLandRect			= CGRectMake(762.0,  25.0, 180.0,  21.0);
	attackInitialSliderLandRect			= CGRectMake(760.0,  55.0, 246.0,  23.0);
	attackInitialTextFieldLandRect		= CGRectMake(942.0,  20.0,  62.0,  31.0);
	attackDecayLabelLandRect			= CGRectMake(762.0, 103.0, 180.0,  21.0);
	attackDecaySliderLandRect			= CGRectMake(760.0, 133.0, 246.0,  23.0);
	attackDecayTextFieldLandRect		= CGRectMake(942.0,  98.0,  62.0,  31.0);
	decaySustainLabelLandRect			= CGRectMake(762.0, 181.0, 180.0,  21.0);
	decaySustainSliderLandRect			= CGRectMake(760.0, 211.0, 246.0,  23.0);
	decaySustainTextFieldLandRect		= CGRectMake(942.0, 176.0,  62.0,  31.0);
	sustainReleaseLabelLandRect			= CGRectMake(762.0, 259.0, 180.0,  21.0);
	sustainReleaseSliderLandRect		= CGRectMake(760.0, 289.0, 246.0,  23.0);
	sustainReleaseTextFieldLandRect		= CGRectMake(942.0, 254.0,  62.0,  31.0);
	attackDurationLabelLandRect			= CGRectMake(762.0, 441.0, 180.0,  21.0);
	attackDurationTextFieldLandRect		= CGRectMake(942.0, 436.0,  62.0,  31.0);
	attackDurationSliderLandRect		= CGRectMake(760.0, 471.0, 246.0,  23.0);
	decayDurationLabelLandRect			= CGRectMake(762.0, 519.0, 180.0,  21.0);
	decayDurationTextFieldLandRect		= CGRectMake(942.0, 514.0,  62.0,  31.0);
	decayDurationSliderLandRect			= CGRectMake(760.0, 549.0, 246.0,  23.0);
	sustainDurationLabelLandRect		= CGRectMake(762.0, 597.0, 180.0,  21.0);
	sustainDurationTextFieldLandRect	= CGRectMake(942.0, 592.0,  62.0,  31.0);
	sustainDurationSliderLandRect		= CGRectMake(760.0, 627.0, 246.0,  23.0);
	releaseDurationLabelLandRect		= CGRectMake(762.0, 675.0, 180.0,  21.0);
	releaseDurationTextFieldLandRect	= CGRectMake(942.0, 670.0,  62.0,  31.0);
	releaseDurationSliderLandRect		= CGRectMake(760.0, 705.0, 246.0,  23.0);
}

- (void) viewWillAppear:(BOOL)animated {
	[self refreshDisplayFromStructOneToOneFreq:customOneToOne animated:NO];
	if (!tempOneToOne) tempOneToOne = (struct oneToOneFreq *)malloc(sizeof(struct oneToOneFreq));
	[RKData copyStructOneToOneFreq:customOneToOne to:tempOneToOne];
	[self setVolAndDurSlidersAndTextFields];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	free(tempOneToOne);
    [super dealloc];
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation duration:(NSTimeInterval)duration {
	if ((interfaceOrientation == UIInterfaceOrientationLandscapeLeft) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight)) {
		[ppPicker					setFrame:ppPickerLandRect					];
		[numeratorTF				setFrame:numeratorTFLandRect				];
		[denominatorTF				setFrame:denominatorTFLandRect				];
		[quotientTF					setFrame:quotientTFLandRect					];
		[baseFreqTF					setFrame:baseFreqTFLandRect					];
		[baseFreqXQuotientTF		setFrame:baseFreqXQuotientTFLandRect		];
		[mainTextLabel				setFrame:mainTextLabelLandRect				];
		[secondTextLabel			setFrame:secondTextLabelLandRect			];
		[ppPickerLabel				setFrame:ppPickerLabelLandRect				];
		[numeratorLabel				setFrame:numeratorLabelLandRect				];
		[denominatorLabel			setFrame:denominatorLabelLandRect			];
		[quotientLabel				setFrame:quotientLabelLandRect				];
		[baseFreqLabel				setFrame:baseFreqLabelLandRect				];
		[baseFreqXQuotientLabel		setFrame:baseFreqXQuotientLabelLandRect		];
		[restoreDefaultsButton		setFrame:restoreDefaultsButtonLandRect		];
		[cancelButton				setFrame:cancelButtonLandRect				];
		[applyButton				setFrame:applyButtonLandRect				];
		[attackInitialLabel			setFrame:attackInitialLabelLandRect			];
		[attackInitialSlider		setFrame:attackInitialSliderLandRect		];
		[attackInitialTextField		setFrame:attackInitialTextFieldLandRect		];
		[attackDecayLabel			setFrame:attackDecayLabelLandRect			];
		[attackDecaySlider			setFrame:attackDecaySliderLandRect			];
		[attackDecayTextField		setFrame:attackDecayTextFieldLandRect		];
		[decaySustainLabel			setFrame:decaySustainLabelLandRect			];
		[decaySustainSlider			setFrame:decaySustainSliderLandRect			];
		[decaySustainTextField		setFrame:decaySustainTextFieldLandRect		];
		[sustainReleaseLabel		setFrame:sustainReleaseLabelLandRect		];
		[sustainReleaseSlider		setFrame:sustainReleaseSliderLandRect		];
		[sustainReleaseTextField	setFrame:sustainReleaseTextFieldLandRect	];
		[attackDurationLabel		setFrame:attackDurationLabelLandRect		];
		[attackDurationSlider		setFrame:attackDurationSliderLandRect		];
		[attackDurationTextField	setFrame:attackDurationTextFieldLandRect	];
		[decayDurationLabel			setFrame:decayDurationLabelLandRect			];
		[decayDurationSlider		setFrame:decayDurationSliderLandRect		];
		[decayDurationTextField		setFrame:decayDurationTextFieldLandRect		];
		[sustainDurationLabel		setFrame:sustainDurationLabelLandRect		];
		[sustainDurationSlider		setFrame:sustainDurationSliderLandRect		];
		[sustainDurationTextField	setFrame:sustainDurationTextFieldLandRect	];
		[releaseDurationLabel		setFrame:releaseDurationLabelLandRect		];
		[releaseDurationSlider		setFrame:releaseDurationSliderLandRect		];
		[releaseDurationTextField	setFrame:releaseDurationTextFieldLandRect	];
	} else {
		[ppPicker					setFrame:ppPickerPortRect					];
		[numeratorTF				setFrame:numeratorTFPortRect				];
		[denominatorTF				setFrame:denominatorTFPortRect				];
		[quotientTF					setFrame:quotientTFPortRect					];
		[baseFreqTF					setFrame:baseFreqTFPortRect					];
		[baseFreqXQuotientTF		setFrame:baseFreqXQuotientTFPortRect		];
		[mainTextLabel				setFrame:mainTextLabelPortRect				];
		[secondTextLabel			setFrame:secondTextLabelPortRect			];
		[ppPickerLabel				setFrame:ppPickerLabelPortRect				];
		[numeratorLabel				setFrame:numeratorLabelPortRect				];
		[denominatorLabel			setFrame:denominatorLabelPortRect			];
		[quotientLabel				setFrame:quotientLabelPortRect				];
		[baseFreqLabel				setFrame:baseFreqLabelPortRect				];
		[baseFreqXQuotientLabel		setFrame:baseFreqXQuotientLabelPortRect		];
		[restoreDefaultsButton		setFrame:restoreDefaultsButtonPortRect		];
		[cancelButton				setFrame:cancelButtonPortRect				];
		[applyButton				setFrame:applyButtonPortRect				];
		[attackInitialLabel			setFrame:attackInitialLabelPortRect			];
		[attackInitialSlider		setFrame:attackInitialSliderPortRect		];
		[attackInitialTextField		setFrame:attackInitialTextFieldPortRect		];
		[attackDecayLabel			setFrame:attackDecayLabelPortRect			];
		[attackDecaySlider			setFrame:attackDecaySliderPortRect			];
		[attackDecayTextField		setFrame:attackDecayTextFieldPortRect		];
		[decaySustainLabel			setFrame:decaySustainLabelPortRect			];
		[decaySustainSlider			setFrame:decaySustainSliderPortRect			];
		[decaySustainTextField		setFrame:decaySustainTextFieldPortRect		];
		[sustainReleaseLabel		setFrame:sustainReleaseLabelPortRect		];
		[sustainReleaseSlider		setFrame:sustainReleaseSliderPortRect		];
		[sustainReleaseTextField	setFrame:sustainReleaseTextFieldPortRect	];
		[attackDurationLabel		setFrame:attackDurationLabelPortRect		];
		[attackDurationSlider		setFrame:attackDurationSliderPortRect		];
		[attackDurationTextField	setFrame:attackDurationTextFieldPortRect	];
		[decayDurationLabel			setFrame:decayDurationLabelPortRect			];
		[decayDurationSlider		setFrame:decayDurationSliderPortRect		];
		[decayDurationTextField		setFrame:decayDurationTextFieldPortRect		];
		[sustainDurationLabel		setFrame:sustainDurationLabelPortRect		];
		[sustainDurationSlider		setFrame:sustainDurationSliderPortRect		];
		[sustainDurationTextField	setFrame:sustainDurationTextFieldPortRect	];
		[releaseDurationLabel		setFrame:releaseDurationLabelPortRect		];
		[releaseDurationSlider		setFrame:releaseDurationSliderPortRect		];
		[releaseDurationTextField	setFrame:releaseDurationTextFieldPortRect	];
	}
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
	return (NSInteger)NUMBER_OF_PRIMES;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
	int result = 0;
	if      (component == (NSInteger)0) result = 11;
	else if (component == (NSInteger)1) result =  7;
	else if (component == (NSInteger)2) result =  5;
	else if (component == (NSInteger)3) result =  3;
	else if (component == (NSInteger)4) result =  3;
	return (NSInteger)result;
}

/*
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
	return (CGFloat)50.0;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
	return (CGFloat)0.1;
} */

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	NSString *result = @"";
	if (component == (NSInteger)0) {
		if      (row == (NSInteger)0)  result = @" 32";
		else if (row == (NSInteger)1)  result = @" 16";
		else if (row == (NSInteger)2)  result = @"  8";
		else if (row == (NSInteger)3)  result = @"  4";
		else if (row == (NSInteger)4)  result = @"  2";
		else if (row == (NSInteger)5)  result = @"  1";
		else if (row == (NSInteger)6)  result = @"1/2";
		else if (row == (NSInteger)7)  result = @"1/4";
		else if (row == (NSInteger)8)  result = @"1/8";
		else if (row == (NSInteger)9)  result = @"1/16";
		else if (row == (NSInteger)10) result = @"1/32";
	}
	else if (component == (NSInteger)1) {
		if      (row == (NSInteger)0)  result = @" 27";
		else if (row == (NSInteger)1)  result = @"  9";
		else if (row == (NSInteger)2)  result = @"  3";
		else if (row == (NSInteger)3)  result = @"  1";
		else if (row == (NSInteger)4)  result = @"1/3";
		else if (row == (NSInteger)5)  result = @"1/9";
		else if (row == (NSInteger)6)  result = @"1/27";
	}
	else if (component == (NSInteger)2) {
		if      (row == (NSInteger)0)  result = @" 25";
		else if (row == (NSInteger)1)  result = @"  5";
		else if (row == (NSInteger)2)  result = @"  1";
		else if (row == (NSInteger)3)  result = @"1/5";
		else if (row == (NSInteger)4)  result = @"1/25";
	}
	else if (component == (NSInteger)3) {
		if      (row == (NSInteger)0)  result = @"  7";
		else if (row == (NSInteger)1)  result = @"  1";
		else if (row == (NSInteger)2)  result = @" 1/7";
	}
	else if (component == (NSInteger)4) {
		if      (row == (NSInteger)0)  result = @" 11";
		else if (row == (NSInteger)1)  result = @"  1";
		else if (row == (NSInteger)2)  result = @"1/11";
	}
	return result;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
	if (component == (NSInteger)0) {
		if      (row == (NSInteger)0)  [self setPower:5  forPrime:0]; // "32"
		else if (row == (NSInteger)1)  [self setPower:4  forPrime:0]; // "16"
		else if (row == (NSInteger)2)  [self setPower:3  forPrime:0]; // "8"
		else if (row == (NSInteger)3)  [self setPower:2  forPrime:0]; // "4"
		else if (row == (NSInteger)4)  [self setPower:1  forPrime:0]; // "2"
		else if (row == (NSInteger)5)  [self setPower:0  forPrime:0]; // "1"
		else if (row == (NSInteger)6)  [self setPower:-1 forPrime:0]; // "1/2"
		else if (row == (NSInteger)7)  [self setPower:-2 forPrime:0]; // "1/4"
		else if (row == (NSInteger)8)  [self setPower:-3 forPrime:0]; // "1/8"
		else if (row == (NSInteger)9)  [self setPower:-4 forPrime:0]; // "1/16"
		else if (row == (NSInteger)10) [self setPower:-5 forPrime:0]; // "1/32"
	}
	else if (component == (NSInteger)1) {
		if      (row == (NSInteger)0)  [self setPower:3  forPrime:1]; // "27"
		else if (row == (NSInteger)1)  [self setPower:2  forPrime:1]; // "9"
		else if (row == (NSInteger)2)  [self setPower:1  forPrime:1]; // "3"
		else if (row == (NSInteger)3)  [self setPower:0  forPrime:1]; // "1"
		else if (row == (NSInteger)4)  [self setPower:-1 forPrime:1]; // "1/3"
		else if (row == (NSInteger)5)  [self setPower:-2 forPrime:1]; // "1/9"
		else if (row == (NSInteger)6)  [self setPower:-3 forPrime:1]; // "1/27"
	}
	else if (component == (NSInteger)2) {
		if      (row == (NSInteger)0)  [self setPower:2  forPrime:2]; // "25"
		else if (row == (NSInteger)1)  [self setPower:1  forPrime:2]; // "5"
		else if (row == (NSInteger)2)  [self setPower:0  forPrime:2]; // "1"
		else if (row == (NSInteger)3)  [self setPower:-1 forPrime:2]; // "1/5"
		else if (row == (NSInteger)4)  [self setPower:-2 forPrime:2]; // "1/25"
	}
	else if (component == (NSInteger)3) {
		if      (row == (NSInteger)0)  [self setPower:1  forPrime:3]; // "7"
		else if (row == (NSInteger)1)  [self setPower:0  forPrime:3]; // "1"
		else if (row == (NSInteger)2)  [self setPower:-1 forPrime:3]; // "1/7"
	}
	else if (component == (NSInteger)4) {
		if      (row == (NSInteger)0)  [self setPower:1  forPrime:4]; // "11"
		else if (row == (NSInteger)1)  [self setPower:0  forPrime:4]; // "1"
		else if (row == (NSInteger)2)  [self setPower:-1 forPrime:4]; // "1/11"
	}
}

- (void) textFieldDidBeginEditing:(UITextField *)textField {
	if (textField == baseFreqTF) {
		[restoreDefaultsButton	setEnabled:NO];
		[cancelButton			setEnabled:NO];
		[applyButton			setEnabled:NO];
		[ppPicker				setUserInteractionEnabled:NO];
	}
}

- (void) textFieldDidEndEditing:(UITextField *)textField {
	if (textField == baseFreqTF) {
		[restoreDefaultsButton	setEnabled:YES];
		[cancelButton			setEnabled:YES];
		[applyButton			setEnabled:YES];
		[ppPicker				setUserInteractionEnabled:YES];
	}
}

- (void) refreshDisplayFromStructOneToOneFreq:(struct oneToOneFreq *)source  animated:(BOOL)yesOrNo {
	[ppPicker selectRow:(NSInteger)(5 - source->ratio.pPower[0]) inComponent:(NSInteger)0 animated:yesOrNo];
	[ppPicker selectRow:(NSInteger)(3 - source->ratio.pPower[1]) inComponent:(NSInteger)1 animated:yesOrNo];
	[ppPicker selectRow:(NSInteger)(2 - source->ratio.pPower[2]) inComponent:(NSInteger)2 animated:yesOrNo];
	[ppPicker selectRow:(NSInteger)(1 - source->ratio.pPower[3]) inComponent:(NSInteger)3 animated:yesOrNo];
	[ppPicker selectRow:(NSInteger)(1 - source->ratio.pPower[4]) inComponent:(NSInteger)4 animated:yesOrNo];
	[numeratorTF			setText:[NSString stringWithFormat:@"%d",    source->ratio.numer]];
	[denominatorTF			setText:[NSString stringWithFormat:@"%d",    source->ratio.denom]];
	[quotientTF				setText:[NSString stringWithFormat:@"%5.3f", source->ratio.quotient]];
	[baseFreqTF				setText:[NSString stringWithFormat:@"%5.3f", source->baseFrequency]];
	[baseFreqXQuotientTF	setText:[NSString stringWithFormat:@"%5.3f", source->oneToOneFreq]];
	[[self view] setNeedsDisplay];
}

- (void) setPower:(int)power forPrime:(int)prime {
	int previousValue = tempOneToOne->ratio.pPower[prime];
	tempOneToOne->ratio.pPower[prime] = power;
	[RKRatio fromPrimesCompleteRatio:&tempOneToOne->ratio];
	float new1To1 = tempOneToOne->baseFrequency * tempOneToOne->ratio.quotient;
	if ((new1To1 < MINIMUM_ONETOONE) || (new1To1 > MAXIMUM_ONETOONE)) {
		tempOneToOne->ratio.pPower[prime] = previousValue;
		[RKRatio fromPrimesCompleteRatio:&tempOneToOne->ratio];
		[self refreshDisplayFromStructOneToOneFreq:tempOneToOne animated:YES];
		alert = [[UIAlertView alloc] initWithTitle:@"Settings Reset to Previous Values" message:@"The combination of base frequency and the new prime power resulted in a 1/1 frequency which was too extreme.  All settings have been reset to their values prior to the latest change." delegate:nil cancelButtonTitle:@"Okay" otherButtonTitles:nil]; [alert show]; [alert release];
	} else {
		tempOneToOne->oneToOneFreq = new1To1;
		[self refreshDisplayFromStructOneToOneFreq:tempOneToOne animated:YES];
	}
}

- (IBAction) baseFreqChanged: (id) sender {
	float previousBase = tempOneToOne->baseFrequency;
	float newBase, new1To1;
	if (   ((newBase = [[baseFreqTF text] floatValue]) < 1.0f)
		|| ((new1To1 = newBase * tempOneToOne->ratio.quotient) < MINIMUM_ONETOONE)
		||  (new1To1 > MAXIMUM_ONETOONE)  ) {
		[baseFreqTF setText:[NSString stringWithFormat:@"%5.3f", previousBase]];
		alert = [[UIAlertView alloc] initWithTitle:@"Settings Reset to Previous Values" message:@"Either the new base frequency value was out of range or the combination of the new value and the ratio by which it is multiplied resulted in a 1/1 frequency which was too extreme.  All settings have been reset to their values prior to the latest change." delegate:nil cancelButtonTitle:@"Okay" otherButtonTitles:nil]; [alert show]; [alert release];
	} else {
		tempOneToOne->baseFrequency = newBase;
		tempOneToOne->oneToOneFreq  = new1To1;
		[self refreshDisplayFromStructOneToOneFreq:tempOneToOne animated:NO];
	}
}

- (IBAction) restoreDefaults: (id) sender {
	[RKData copyStructOneToOneFreq:defaultOneToOne to:customOneToOne];
	[RKData copyStructOneToOneFreq:defaultOneToOne to:tempOneToOne];
	[RKData updateStdUserDefaultsFromStructOneToOneFreq:defaultOneToOne];
	[self refreshDisplayFromStructOneToOneFreq:defaultOneToOne animated:YES];
	[RKData setVolumesAndStdDefaultsFromVolumeDefaults];
	[RKData setDurationsAndStdDefaultsFromDurationDefaults];
	[self setVolAndDurSlidersAndTextFields];
}

- (IBAction) cancel: (id) sender {
	[RKData copyStructOneToOneFreq:customOneToOne to:tempOneToOne];
	[RKData updateStdUserDefaultsFromStructOneToOneFreq:customOneToOne];
	[RKData setVolumesFromStdUserDefaults];
	[RKData setDurationsFromStdUserDefaults];
	[[self parentViewController] dismissModalViewControllerAnimated:YES];
}

- (IBAction) apply: (id) sender {
	[RKData copyStructOneToOneFreq:tempOneToOne to:customOneToOne];
	[RKData updateStdUserDefaultsFromStructOneToOneFreq:tempOneToOne];
	[RKData updateStdUserDefaultsFromVolumeSettings];
	[RKData updateStdUserDefaultsFromDurationSettings];
	[[self parentViewController] dismissModalViewControllerAnimated:YES];
}

- (IBAction) volumeChanged: (id) sender {
	if		  (sender == attackInitialSlider)  {
		volumeSettings->attackInitialVolume    = [attackInitialSlider value];
		[attackInitialTextField setText:[NSString stringWithFormat:@"%4.2f",  volumeSettings->attackInitialVolume]];
	} else if (sender == attackDecaySlider)    {
		volumeSettings->attackDecayBndryVol    = [attackDecaySlider value];
		[attackDecayTextField setText:[NSString stringWithFormat:@"%4.2f",    volumeSettings->attackDecayBndryVol]];
	} else if (sender == decaySustainSlider)   {
		volumeSettings->decaySustainBndryVol   = [decaySustainSlider value];
		[decaySustainTextField setText:[NSString stringWithFormat:@"%4.2f",   volumeSettings->decaySustainBndryVol]];
	} else if (sender == sustainReleaseSlider) {
		volumeSettings->sustainReleaseBndryVol = [sustainReleaseSlider value];
		[sustainReleaseTextField setText:[NSString stringWithFormat:@"%4.2f", volumeSettings->sustainReleaseBndryVol]];
	} else {
	}
}

- (IBAction) durationChanged: (id) sender {
	if		  (sender == attackDurationSlider)	{
		durationSettings->attackDuration = [attackDurationSlider value];
		[attackDurationTextField setText:[NSString stringWithFormat:@"%4.2f",  durationSettings->attackDuration]];
	} else if (sender == decayDurationSlider)	{
		durationSettings->decayDuration = [decayDurationSlider value];
		[decayDurationTextField setText:[NSString stringWithFormat:@"%4.2f",   durationSettings->decayDuration]];
	} else if (sender == sustainDurationSlider)	{
		durationSettings->sustainDuration = [sustainDurationSlider value];
		[sustainDurationTextField setText:[NSString stringWithFormat:@"%4.2f", durationSettings->sustainDuration]];
	} else if (sender == releaseDurationSlider)	{
		durationSettings->releaseDuration = [releaseDurationSlider value];
		[releaseDurationTextField setText:[NSString stringWithFormat:@"%4.2f", durationSettings->releaseDuration]];
	} else {
	}
}

- (void) setVolAndDurSlidersAndTextFields {
	[attackInitialSlider   setValue:volumeSettings->attackInitialVolume    animated:NO];
	[attackDecaySlider     setValue:volumeSettings->attackDecayBndryVol    animated:NO];
	[decaySustainSlider    setValue:volumeSettings->decaySustainBndryVol   animated:NO];
	[sustainReleaseSlider  setValue:volumeSettings->sustainReleaseBndryVol animated:NO];
	[attackDurationSlider  setValue:durationSettings->attackDuration       animated:NO];
	[decayDurationSlider   setValue:durationSettings->decayDuration        animated:NO];
	[sustainDurationSlider setValue:durationSettings->sustainDuration      animated:NO];
	[releaseDurationSlider setValue:durationSettings->releaseDuration      animated:NO];

	[attackInitialTextField   setText:[NSString stringWithFormat:@"%4.2f", volumeSettings->attackInitialVolume   ]];
	[attackDecayTextField     setText:[NSString stringWithFormat:@"%4.2f", volumeSettings->attackDecayBndryVol   ]];
	[decaySustainTextField    setText:[NSString stringWithFormat:@"%4.2f", volumeSettings->decaySustainBndryVol  ]];
	[sustainReleaseTextField  setText:[NSString stringWithFormat:@"%4.2f", volumeSettings->sustainReleaseBndryVol]];
	[attackDurationTextField  setText:[NSString stringWithFormat:@"%4.2f", durationSettings->attackDuration      ]];
	[decayDurationTextField   setText:[NSString stringWithFormat:@"%4.2f", durationSettings->decayDuration       ]];
	[sustainDurationTextField setText:[NSString stringWithFormat:@"%4.2f", durationSettings->sustainDuration     ]];
	[releaseDurationTextField setText:[NSString stringWithFormat:@"%4.2f", durationSettings->releaseDuration     ]];
}

@end
