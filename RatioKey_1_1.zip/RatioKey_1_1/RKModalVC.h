// File: RKModalVC.h
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import <UIKit/UIKit.h>
#import "RKData.h"

@interface RKModalVC : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate> {

}

@property (nonatomic, assign) IBOutlet UIPickerView	*ppPicker;
@property (nonatomic, assign) IBOutlet UITextField	*numeratorTF;
@property (nonatomic, assign) IBOutlet UITextField	*denominatorTF;
@property (nonatomic, assign) IBOutlet UITextField	*quotientTF;
@property (nonatomic, assign) IBOutlet UITextField	*baseFreqTF;
@property (nonatomic, assign) IBOutlet UITextField	*baseFreqXQuotientTF;
@property (nonatomic, assign) IBOutlet UILabel		*mainTextLabel;
@property (nonatomic, assign) IBOutlet UILabel		*secondTextLabel;
@property (nonatomic, assign) IBOutlet UILabel		*ppPickerLabel;
@property (nonatomic, assign) IBOutlet UILabel		*numeratorLabel;
@property (nonatomic, assign) IBOutlet UILabel		*denominatorLabel;
@property (nonatomic, assign) IBOutlet UILabel		*quotientLabel;
@property (nonatomic, assign) IBOutlet UILabel		*baseFreqLabel;
@property (nonatomic, assign) IBOutlet UILabel		*baseFreqXQuotientLabel;
@property (nonatomic, assign) IBOutlet UIButton		*restoreDefaultsButton;
@property (nonatomic, assign) IBOutlet UIButton		*cancelButton;
@property (nonatomic, assign) IBOutlet UIButton		*applyButton;
@property (nonatomic, assign) IBOutlet UIView		*separatorView;
@property (nonatomic, assign) IBOutlet UILabel		*attackInitialLabel;
@property (nonatomic, assign) IBOutlet UISlider		*attackInitialSlider;
@property (nonatomic, assign) IBOutlet UITextField	*attackInitialTextField;
@property (nonatomic, assign) IBOutlet UILabel		*attackDecayLabel;
@property (nonatomic, assign) IBOutlet UISlider		*attackDecaySlider;
@property (nonatomic, assign) IBOutlet UITextField	*attackDecayTextField;
@property (nonatomic, assign) IBOutlet UILabel		*decaySustainLabel;
@property (nonatomic, assign) IBOutlet UISlider		*decaySustainSlider;
@property (nonatomic, assign) IBOutlet UITextField	*decaySustainTextField;
@property (nonatomic, assign) IBOutlet UILabel		*sustainReleaseLabel;
@property (nonatomic, assign) IBOutlet UISlider		*sustainReleaseSlider;
@property (nonatomic, assign) IBOutlet UITextField	*sustainReleaseTextField;
@property (nonatomic, assign) IBOutlet UILabel		*attackDurationLabel;
@property (nonatomic, assign) IBOutlet UISlider		*attackDurationSlider;
@property (nonatomic, assign) IBOutlet UITextField	*attackDurationTextField;
@property (nonatomic, assign) IBOutlet UILabel		*decayDurationLabel;
@property (nonatomic, assign) IBOutlet UISlider		*decayDurationSlider;
@property (nonatomic, assign) IBOutlet UITextField	*decayDurationTextField;
@property (nonatomic, assign) IBOutlet UILabel		*sustainDurationLabel;
@property (nonatomic, assign) IBOutlet UISlider		*sustainDurationSlider;
@property (nonatomic, assign) IBOutlet UITextField	*sustainDurationTextField;
@property (nonatomic, assign) IBOutlet UILabel		*releaseDurationLabel;
@property (nonatomic, assign) IBOutlet UISlider		*releaseDurationSlider;
@property (nonatomic, assign) IBOutlet UITextField	*releaseDurationTextField;

- (void) setPower:(int)power forPrime:(int)prime;
- (void) refreshDisplayFromStructOneToOneFreq:(struct oneToOneFreq *)source animated:(BOOL)yesOrNo;
- (IBAction) baseFreqChanged: (id) sender;
- (IBAction) restoreDefaults: (id) sender;
- (IBAction) cancel: (id) sender;
- (IBAction) apply: (id) sender;
- (IBAction) volumeChanged: (id) sender;
- (IBAction) durationChanged: (id) sender;
- (void) setVolAndDurSlidersAndTextFields;

@end
