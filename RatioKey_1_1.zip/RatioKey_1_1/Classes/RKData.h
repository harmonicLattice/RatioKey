// File: RKData.h
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import <Foundation/Foundation.h>
#import "RKRatio.h"

@interface RKData : NSObject {

}

+ (void) setup;
+ (void) setVolumesAndStdDefaultsFromVolumeDefaults;
+ (void) setDurationsAndStdDefaultsFromDurationDefaults;
+ (void) setVolumesFromStdUserDefaults;
+ (void) setDurationsFromStdUserDefaults;
+ (void) updateStdUserDefaultsFromVolumeSettings;
+ (void) updateStdUserDefaultsFromDurationSettings;
+ (void) updateStdUserDefaultsFromStructOneToOneFreq:(struct oneToOneFreq *)source;
+ (void) setStructOneToOneFromStdUserDefaults:(struct oneToOneFreq *)target;
+ (BOOL) setStructOneToOneFreq:(struct oneToOneFreq *)target fromBase:(float)base numer:(UInt32)n andDenom:(UInt32)d;
+ (void)copyStructOneToOneFreq:(struct oneToOneFreq *)source to:(struct oneToOneFreq *)target;

@end
