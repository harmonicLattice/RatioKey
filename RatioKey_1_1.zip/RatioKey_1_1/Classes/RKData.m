// File: RKData.m
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import "RKData.h"

extern struct oneToOneFreq *defaultOneToOne, *customOneToOne;
extern struct durationADSR *durationSettings;
extern struct volumeADSR   *volumeSettings;
extern NSUserDefaults *stdDefaults;

@implementation RKData

+ (void) setup {
	stdDefaults      = [NSUserDefaults standardUserDefaults];
	defaultOneToOne  = (struct oneToOneFreq *)malloc(sizeof(struct oneToOneFreq));
	customOneToOne   = (struct oneToOneFreq *)malloc(sizeof(struct oneToOneFreq));
	durationSettings = (struct durationADSR *)malloc(sizeof(struct durationADSR));
	volumeSettings   = (struct volumeADSR   *)malloc(sizeof(struct volumeADSR));
	
	defaultOneToOne->baseFrequency		= DEFAULT_BASEFREQUENCY;
	defaultOneToOne->ratio.pPower[0]	= 3; // power of  2
	defaultOneToOne->ratio.pPower[1]	= 0; // power of  3
	defaultOneToOne->ratio.pPower[2]	= 1; // power of  5
	defaultOneToOne->ratio.pPower[3]	= 0; // power of  7
	defaultOneToOne->ratio.pPower[4]	= 0; // power of 11
	defaultOneToOne->ratio.numer		= DEFAULT_NUMERATOR;
	defaultOneToOne->ratio.denom		= DEFAULT_DENOMINATOR;
	defaultOneToOne->ratio.quotient		= DEFAULT_QUOTIENT;
	defaultOneToOne->oneToOneFreq		= DEFAULT_ONETOONEFREQ;
}

+ (void) setVolumesAndStdDefaultsFromVolumeDefaults {
	volumeSettings->attackInitialVolume    = DEFAULT_ATTACK_INITIAL_VOLUME;
	volumeSettings->attackDecayBndryVol    = DEFAULT_ATTACK_DECAY_BNDRY_VOL;
	volumeSettings->decaySustainBndryVol   = DEFAULT_DECAY_SUSTAIN_BNDRY_VOL;
	volumeSettings->sustainReleaseBndryVol = DEFAULT_SUSTAIN_RELEASE_BNDRY_VOL;
	[stdDefaults setFloat:DEFAULT_ATTACK_INITIAL_VOLUME     forKey:@"AttackInitialVolume"];
	[stdDefaults setFloat:DEFAULT_ATTACK_DECAY_BNDRY_VOL    forKey:@"AttackDecayBndryVol"];
	[stdDefaults setFloat:DEFAULT_DECAY_SUSTAIN_BNDRY_VOL   forKey:@"DecaySustainBndryVol"];
	[stdDefaults setFloat:DEFAULT_SUSTAIN_RELEASE_BNDRY_VOL forKey:@"SustainReleaseBndryVol"]; 
	[stdDefaults synchronize];
}

+ (void) setDurationsAndStdDefaultsFromDurationDefaults {
	durationSettings->attackDuration  = DEFAULT_ATTACK_DURATION;
	durationSettings->decayDuration   = DEFAULT_DECAY_DURATION;
	durationSettings->sustainDuration = DEFAULT_SUSTAIN_DURATION;
	durationSettings->releaseDuration = DEFAULT_RELEASE_DURATION;
	[stdDefaults setFloat:DEFAULT_ATTACK_DURATION  forKey:@"AttackDuration"];
	[stdDefaults setFloat:DEFAULT_DECAY_DURATION   forKey:@"DecayDuration"];
	[stdDefaults setFloat:DEFAULT_SUSTAIN_DURATION forKey:@"SustainDuration"];
	[stdDefaults setFloat:DEFAULT_RELEASE_DURATION forKey:@"ReleaseDuration"];
	[stdDefaults synchronize];
}

+ (void) setVolumesFromStdUserDefaults {
	float temp;
	
	temp = [stdDefaults floatForKey:@"AttackInitialVolume"];
	volumeSettings->attackInitialVolume = temp;
	
	temp = [stdDefaults floatForKey:@"AttackDecayBndryVol"];
	volumeSettings->attackDecayBndryVol = temp;
	
	temp = [stdDefaults floatForKey:@"DecaySustainBndryVol"];
	volumeSettings->decaySustainBndryVol = temp;
	
	temp = [stdDefaults floatForKey:@"SustainReleaseBndryVol"];
	volumeSettings->sustainReleaseBndryVol = temp;
}

+ (void) setDurationsFromStdUserDefaults {
	float temp;
	
	temp  = [stdDefaults floatForKey:@"AttackDuration"];
	durationSettings->attackDuration  = temp;

	temp   = [stdDefaults floatForKey:@"DecayDuration"];
	durationSettings->decayDuration   = temp;

	temp = [stdDefaults floatForKey:@"SustainDuration"];
	durationSettings->sustainDuration = temp;

	temp = [stdDefaults floatForKey:@"ReleaseDuration"];
	durationSettings->releaseDuration = temp;
}

+ (void) updateStdUserDefaultsFromVolumeSettings {
	[stdDefaults setFloat:volumeSettings->attackInitialVolume    forKey:@"AttackInitialVolume"];
	[stdDefaults setFloat:volumeSettings->attackDecayBndryVol    forKey:@"AttackDecayBndryVol"];
	[stdDefaults setFloat:volumeSettings->decaySustainBndryVol   forKey:@"DecaySustainBndryVol"];
	[stdDefaults setFloat:volumeSettings->sustainReleaseBndryVol forKey:@"SustainReleaseBndryVol"]; 
	[stdDefaults synchronize];
}

+ (void) updateStdUserDefaultsFromDurationSettings {
	[stdDefaults setFloat:durationSettings->attackDuration  forKey:@"AttackDuration"];
	[stdDefaults setFloat:durationSettings->decayDuration   forKey:@"DecayDuration"];
	[stdDefaults setFloat:durationSettings->sustainDuration forKey:@"SustainDuration"];
	[stdDefaults setFloat:durationSettings->releaseDuration forKey:@"ReleaseDuration"];
	[stdDefaults synchronize];
}

+ (void) updateStdUserDefaultsFromStructOneToOneFreq:(struct oneToOneFreq *)source {
	[stdDefaults setFloat:source->baseFrequency forKey:@"Base_Frequency"];
	[stdDefaults setInteger:(NSInteger)source->ratio.numer forKey:@"Numerator"];	
	[stdDefaults setInteger:(NSInteger)source->ratio.denom forKey:@"Denominator"];
	[stdDefaults synchronize];
}

+ (void) setStructOneToOneFromStdUserDefaults:(struct oneToOneFreq *)target {
	if (   !(target->baseFrequency = [stdDefaults   floatForKey:@"Base_Frequency"])
		|| !(target->ratio.numer   = [stdDefaults integerForKey:@"Numerator"])
		|| !(target->ratio.denom   = [stdDefaults integerForKey:@"Denominator"]) )
	{
		target->baseFrequency = DEFAULT_BASEFREQUENCY;
		target->ratio.numer   = DEFAULT_NUMERATOR;
		target->ratio.denom   = DEFAULT_DENOMINATOR;
	}
	target->oneToOneFreq = target->baseFrequency * ((float)target->ratio.numer / (float)target->ratio.denom);
	[RKRatio setStructRatio:&target->ratio fromNum:target->ratio.numer andDen:target->ratio.denom];
}

+ (BOOL) setStructOneToOneFreq:(struct oneToOneFreq *)target fromBase:(float)base numer:(UInt32)n andDenom:(UInt32)d {
	if (base < 1.0f) return NO;
	if (![RKRatio setStructRatio:&target->ratio fromNum:n andDen:d]) return NO;
	float oneToOne = base * target->ratio.quotient;
	if ((oneToOne < MINIMUM_ONETOONE) || (oneToOne > MAXIMUM_ONETOONE)) return NO;
	target->baseFrequency = base;
	target->oneToOneFreq  = oneToOne;
	return YES;
}

+ (void)copyStructOneToOneFreq:(struct oneToOneFreq *)source to:(struct oneToOneFreq *)target {
	target->baseFrequency	= source->baseFrequency;
	[RKRatio copyStructRatio:&source->ratio to:&target->ratio];
	target->oneToOneFreq	= source->oneToOneFreq;
}

- (void)dealloc {
	free(defaultOneToOne);
	free(customOneToOne);
	free(durationSettings);
	free(volumeSettings);
    [super dealloc];
}

@end
