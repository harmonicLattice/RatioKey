// File: RatioKeyAppDelegate.m
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import "RatioKeyAppDelegate.h"

@implementation RatioKeyAppDelegate

@synthesize window;
@synthesize viewController;

- (void)awakeFromNib {
	[super awakeFromNib];
	[RKData setup];
	float versionRK = [stdDefaults floatForKey:@"RatioKey_Version"];
	if (versionRK < RATIOKEY_VERSION) {
		[RKData updateStdUserDefaultsFromStructOneToOneFreq:defaultOneToOne];
		[RKData copyStructOneToOneFreq:defaultOneToOne to:customOneToOne];
		[RKData setVolumesAndStdDefaultsFromVolumeDefaults];
		[RKData setDurationsAndStdDefaultsFromDurationDefaults];
		[stdDefaults setFloat:RATIOKEY_VERSION forKey:@"RatioKey_Version"];
		[stdDefaults synchronize];
	} else {
		[RKData setStructOneToOneFromStdUserDefaults:customOneToOne];
		[RKData setVolumesFromStdUserDefaults];
		[RKData setDurationsFromStdUserDefaults];
	}
}

- (void)applicationDidFinishLaunching:(UIApplication *)application {
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}

/* - (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {} */

- (void)applicationDidBecomeActive:(UIApplication *)application {
	if (!stdDefaults) stdDefaults = [NSUserDefaults standardUserDefaults];
}

- (void) applicationWillResignActive:(UIApplication *)application {
	[NSUserDefaults resetStandardUserDefaults];
	stdDefaults = nil;
}

- (void)applicationWillTerminate:(UIApplication *)application {
	[NSUserDefaults resetStandardUserDefaults];
	stdDefaults = nil;
}

- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}

@end
