// File: RatioKeyAppDelegate.h
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import <UIKit/UIKit.h>
#import "RatioKeyViewController.h"

@interface RatioKeyAppDelegate : NSObject <UIApplicationDelegate> {
	
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet RatioKeyViewController *viewController;

@end

