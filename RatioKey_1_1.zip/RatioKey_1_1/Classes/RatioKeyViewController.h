// File: RatioKeyViewController.h
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import <UIKit/UIKit.h>
#import "RKAudioEngine.h"
#import "RKModalVC.h"

@interface RatioKeyViewController : UIViewController {
	
}

@property (nonatomic, retain) AVAudioSession	*session;
@property (nonatomic, retain) RKAudioEngine		*audioEngine;
@property (nonatomic, retain) RKModalVC			*modalVC;

- (void) buttonPressed:(id)sender;
- (void) optionPressed:(id)sender;

@end

