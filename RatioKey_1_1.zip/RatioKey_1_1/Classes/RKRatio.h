// File: RKRatio.h
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import <Foundation/Foundation.h>

@interface RKRatio : NSObject {

}

+ (struct ratio *) copyStructRatio:(struct ratio *)source to:(struct ratio *)target;
+ (BOOL) setStructRatio:(struct ratio *)target fromNum:(UInt32)num andDen:(UInt32)den;
+ (struct ratio *) fromPrimesCompleteRatio:(struct ratio *)ratio;
+ (struct ratio *) unifyStructRatio:(struct ratio *)thisOne;

@end
