// File: RKAudioEngine.m
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import "RKAudioEngine.h"

const float twoPiDivBySineTableSize	= (float)TWO_PI / (float)SINE_TABLE_SIZE;
TrackNote *oldNote = NULL;
TrackNote *newNote = NULL;
int tnx = -1;

float sineTable[SINE_TABLE_SIZE];
void setupSineTable() {
	float radians;
	int i;
	for (i = 0; i < SINE_TABLE_SIZE; i++) {
		radians = (float)i * twoPiDivBySineTableSize;
		sineTable[i] = (float)(sin(radians));
	}
}

TrackNote *que[TRACKNOTE_QUEUE_SIZE];
void setupTrackNote() {
	for (int i = 0; i < TRACKNOTE_QUEUE_SIZE; i++) {
		que[i] = (TrackNote *)malloc(sizeof(TrackNote));
	}
}

SInt32 *bufferPtr		= NULL;		// pointer to write location for each successive sample
int emptySlots			= 0;		// callback frames not yet filled
int frameCount			= 0;		// frames to be filled on current pass through for loop
int frame				= 0;		// index for for loop
int startStage			= 0;		// holder for original value of stage upon new iteration of while loop
int remSamp				= 0;		// holder for newNote->remainingSamples[x]
float phase				= 0.0f;		// the current state of the sine-cycle, in table indices
float deltaPhase		= 0.0f;		// equivalent to newNote->tableIndicesPerSamp
float currentVolume		= 0.0f;		// changing volume through lifecycle of note, not user setting
float sineTableSizeF	= (float)SINE_TABLE_SIZE;
OSStatus renderCallback (
						 void							*inRefCon,
						 AudioUnitRenderActionFlags		*ioActionFlags,
						 const AudioTimeStamp			*inTimeStamp,
						 UInt32							 inBusNumber,
						 UInt32							 inNumberFrames,
						 AudioBufferList				*ioData
						 ) {
	if (newNote != oldNote) {
		if (oldNote->stage != 4) {
			newNote->changeInVolPerSamp[0] = (newNote->attackDecayBndryVol - currentVolume) / (float)newNote->remainingSamples[0];
		} else {
			currentVolume = newNote->attackInitialVol;
		}
		deltaPhase = newNote->tableIndicesPerSamp;
		oldNote = newNote;
	}
	emptySlots = (int)inNumberFrames;
	bufferPtr = (SInt32 *)ioData->mBuffers[0].mData;	
	while (emptySlots) {
		switch (startStage = newNote->stage) {
			case 0: {
				if ((remSamp = newNote->remainingSamples[0]) > emptySlots) {
					newNote->remainingSamples[0] -= (frameCount = emptySlots);
					emptySlots = 0;
				} else {
					emptySlots -= (frameCount = remSamp);
					newNote->remainingSamples[0] = 0;
					newNote->stage = 1;
				}
			} break;
			case 1: {
				if ((remSamp = newNote->remainingSamples[1]) > emptySlots) {
					newNote->remainingSamples[1] -= (frameCount = emptySlots);
					emptySlots = 0;
				} else {
					emptySlots -= (frameCount = remSamp);
					newNote->remainingSamples[1] = 0;
					newNote->stage = 2;
				}
			} break;
			case 2: {
				if ((remSamp = newNote->remainingSamples[2]) > emptySlots) {
					newNote->remainingSamples[2] -= (frameCount = emptySlots);
					emptySlots = 0;
				} else {
					emptySlots -= (frameCount = remSamp);
					newNote->remainingSamples[2] = 0;
					newNote->stage = 3;
				}
			} break;
			case 3: {
				if ((remSamp = newNote->remainingSamples[3]) > emptySlots) {
					newNote->remainingSamples[3] -= (frameCount = emptySlots);
					emptySlots = 0;
				} else {
					emptySlots -= (frameCount = remSamp);
					newNote->remainingSamples[3] = 0;
					newNote->stage = 4;
				}
			} break;
			case 4: {
				frameCount = emptySlots;
				emptySlots = 0;
			} break;
			default:
				break;
		} // end switch statement
		if (startStage != 4) {
			for ( frame = 0; frame < frameCount; frame++ ) {
				currentVolume += newNote->changeInVolPerSamp[startStage];
				phase += deltaPhase;
				if (phase >= sineTableSizeF) phase -= sineTableSizeF;
				*bufferPtr = (SInt32)(currentVolume * sineTable[(int)phase] * BIT_SHIFT);
				bufferPtr++;
			}
		} else {
			memset(bufferPtr, 0, (size_t)(inNumberFrames * 4));
			phase  = 0.0f;
		}
	} // end while loop
	return (SInt32)0;
}

AudioComponentInstance outputAudUnit;
AudioUnitElement outputBus = 0;
void setupOutputAudUnit() {
	
	AudioComponentDescription description;
	description.componentType = kAudioUnitType_Output;
	description.componentSubType = kAudioUnitSubType_RemoteIO;
	description.componentManufacturer = kAudioUnitManufacturer_Apple;
	description.componentFlags = 0;
	description.componentFlagsMask = 0;
	
	AudioComponent component = AudioComponentFindNext (
													   NULL,
													   &description
													   );
	
	AudioComponentInstanceNew (
							   component, 
							   &outputAudUnit
							   );
	
	UInt32 enable = 1;
	AudioUnitSetProperty (
						  outputAudUnit,
						  kAudioOutputUnitProperty_EnableIO,
						  kAudioUnitScope_Output,
						  outputBus,
						  &enable,
						  sizeof(enable)
						  );
	
	AudioStreamBasicDescription ASBD;
	memset (&ASBD, 0, sizeof(ASBD));
	ASBD.mSampleRate = SAMPLE_RATE;
	ASBD.mFormatID = kAudioFormatLinearPCM;
	ASBD.mFormatFlags = kAudioFormatFlagsAudioUnitCanonical;
	ASBD.mBytesPerPacket = 4;
	ASBD.mFramesPerPacket = 1;
	ASBD.mBytesPerFrame = 4;
	ASBD.mChannelsPerFrame = 1;
	ASBD.mBitsPerChannel = 32;
	ASBD.mReserved = 0;
	
	AudioUnitSetProperty (
						  outputAudUnit,
						  kAudioUnitProperty_StreamFormat,
						  kAudioUnitScope_Input,
						  outputBus,
						  &ASBD,
						  sizeof(ASBD)
						  );
	
	AURenderCallbackStruct renderCallbackStruct;
	renderCallbackStruct.inputProc = renderCallback;
	renderCallbackStruct.inputProcRefCon = NULL;
	AudioUnitSetProperty (
						  outputAudUnit,
						  kAudioUnitProperty_SetRenderCallback,
						  kAudioUnitScope_Input,
						  outputBus,
						  &renderCallbackStruct,
						  sizeof(renderCallbackStruct)
						  );
}

RKAudioEngine *singleAudioEngineInstance = nil;

@implementation RKAudioEngine

+ (RKAudioEngine *)getSingleInstance {
	if (!singleAudioEngineInstance) singleAudioEngineInstance = [[RKAudioEngine alloc] init];
	return singleAudioEngineInstance;
}

- (void)setup {
	setupSineTable();
	setupTrackNote();
	oldNote = newNote = [self newTrackNote];
	newNote->stage = 4;
	setupOutputAudUnit();
	AudioUnitInitialize (outputAudUnit);
}

- (void)start {
	AudioOutputUnitStart(outputAudUnit);
}

- (TrackNote *) newTrackNote {
	tnx++;
	if (tnx > (TRACKNOTE_QUEUE_SIZE - 1)) tnx = 0;
	return que[tnx];
}

- (void) setTNAsNewNote:(TrackNote *)new {
	newNote = new;
}

- (void)stop {
	AudioOutputUnitStop (outputAudUnit);
}

- (void)dealloc {
	AudioUnitUninitialize(outputAudUnit);
	AudioComponentInstanceDispose (outputAudUnit);
	[super dealloc];
}

@end