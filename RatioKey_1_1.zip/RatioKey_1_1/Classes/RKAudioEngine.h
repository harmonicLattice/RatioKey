// File: RKAudioEngine.h
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>

@interface RKAudioEngine : NSObject {
	
}

+ (RKAudioEngine *)getSingleInstance;
- (void)setup;
- (void)start;
- (TrackNote *) newTrackNote;
- (void) setTNAsNewNote:(TrackNote *)new;
- (void)stop;

@end
