// File: RatioKeyViewController.m
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import <UIKit/UIKit.h>
#import "RatioKeyViewController.h"

float oneToOneFreq;
float sineTableSizeDivBySampleRate = (float)SINE_TABLE_SIZE / SAMPLE_RATE;

struct ratio *ratios[128];
int ratioCount = 0;
int tag;
TrackNote *newTN;

struct buttonValues {
	UInt32		 numer;
	UInt32		 denom;
	float		 quotient;
	float		 pitch;
	float		 tableIndicesPerSample;
	CGRect		 portraitRect;
	CGRect		 landscapeRect;
	UIButton	*button;
	NSString	*label;
} btnMap[NUMBER_OF_BUTTONS];

UIButton *upperOptionButton;
UIButton *lowerOptionButton;
CGRect upperOBPortraitRect;
CGRect upperOBLandscapeRect;
CGRect lowerOBPortraitRect;
CGRect lowerOBLandscapeRect;

@implementation RatioKeyViewController

@synthesize session;
@synthesize audioEngine;
@synthesize modalVC;

- (void) awakeFromNib {
	[super awakeFromNib];
	oneToOneFreq = customOneToOne->oneToOneFreq;
	[[self view] setBackgroundColor:[UIColor colorWithRed:0.375 green:0.0 blue:0.375 alpha:1.0]];
	[self setModalVC:nil];
	
	// acquire constraints on ratios here
	struct ratio *temp;
	float q;
	UInt32 n, d;
	int i, exp2, exp3, exp5, exp7, exp11, sumExpXPrime;
	for (exp2 = -5; exp2 < 6; exp2++) {
		for (exp3 = -3; exp3 < 4; exp3++) {
			for (exp5 = -2; exp5 < 3; exp5++) {
				for (exp7 = -1; exp7 < 2; exp7++) {
					for (exp11 = -1; exp11 < 2; exp11++) {
						n = d = (UInt32)1;
						if      (exp2  > 0) for (i = exp2; i > 0; i--) n *= (UInt32)2; 
						else if (exp2  < 0) for (i = exp2; i < 0; i++) d *= (UInt32)2;
						if      (exp3  > 0) for (i = exp3; i > 0; i--) n *= (UInt32)3; 
						else if (exp3  < 0) for (i = exp3; i < 0; i++) d *= (UInt32)3;
						if      (exp5  > 0) for (i = exp5; i > 0; i--) n *= (UInt32)5;
						else if (exp5  < 0) for (i = exp5; i < 0; i++) d *= (UInt32)5;
						if      (exp7  > 0)                            n *= (UInt32)7;
						else if (exp7  < 0)                            d *= (UInt32)7;
						if      (exp11 > 0)                            n *= (UInt32)11;
						else if (exp11 < 0)                            d *= (UInt32)11;
						q = (float)n / (float)d;
						sumExpXPrime = (abs(exp2) * 2) + (abs(exp3) * 3) + (abs(exp5) * 5) + (abs(exp7) * 7) + (abs(exp11) * 11);
						if (sumExpXPrime > 21);			// eliminates candidates with a high sumExpXPrime factor
						else if (q > 2.0);				// eliminates candidates more than an octave above 1:1
						else if (q < 0.5);				// eliminates candidates more than an octave below 1:1
						else if ((n > 32) || (d > 32));	// eliminates candidates with a numerator and/or a denominator >32
						else {							// creates struct ratio structure for any that survive the above tests
							temp = (struct ratio *)(malloc(sizeof(struct ratio)));
							temp->numer			= n;
							temp->denom			= d;
							temp->quotient		= q;
							ratios[ratioCount]	= temp;
							ratioCount++;
						}
					}
				}
			}
		}
	}
	// beginning sort of ratios[]
	struct ratio *oneOrMore[64];
	struct ratio *lessThan1[64];
	int oneOrMoreIndex = 0;
	int lessThan1Index = 0;
	for (i = 0; i < ratioCount; i++) {
		if (ratios[i]->quotient < 1.0f) {
			lessThan1[lessThan1Index] = ratios[i];
			lessThan1Index++;
		} else {
			oneOrMore[oneOrMoreIndex] = ratios[i];
			oneOrMoreIndex++;
		}
	}
	int ratiosIndex = 0;
	int j;
	struct ratio *swap;
	for (i = 0; i < oneOrMoreIndex; i++) {
		swap = oneOrMore[i];
		for (j = i + 1; j < oneOrMoreIndex; j++) {
			if (oneOrMore[j]->quotient > swap->quotient) {
				temp = swap;
				swap = oneOrMore[j];
				oneOrMore[j] = temp;
			}
		}
		ratios[ratiosIndex] = swap;
		ratiosIndex++;
	}
	for (i = 0; i < lessThan1Index; i++) {
		swap = lessThan1[i];
		for (j = i + 1; j < lessThan1Index; j++) {
			if (lessThan1[j]->quotient > swap->quotient) {
				temp = swap;
				swap = lessThan1[j];
				lessThan1[j] = temp;
			}
		}
		ratios[ratiosIndex] = swap;
		ratiosIndex++;
	}
	
	upperOptionButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	upperOptionButton.titleLabel.font = [UIFont boldSystemFontOfSize: 18];
	[upperOptionButton setTitle:@"Options" forState:UIControlStateNormal];
	[upperOptionButton setTitle:@"Options" forState:UIControlStateHighlighted];
    [upperOptionButton setTitle:@"Options" forState:UIControlStateSelected];
	lowerOptionButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	lowerOptionButton.titleLabel.font = [UIFont boldSystemFontOfSize: 18];
	[lowerOptionButton setTitle:@"Options" forState:UIControlStateNormal];
	[lowerOptionButton setTitle:@"Options" forState:UIControlStateHighlighted];
    [lowerOptionButton setTitle:@"Options" forState:UIControlStateSelected];
	
	// beginning setup of btnMap[], including CGRects for portrait orientation
	int   numberOfRows		= ROWS_IN_PORTRAIT;
	int   buttonsPerRow		= PORTRAIT_BTNSPERROW;
	int   startPosition		= PORTRAIT_STARTPOS;
	int   numberOfButtons	= NUMBER_OF_BUTTONS;
	
	CGRect area = CGRectMake(20.0f, 20.0f, 728.0f, 964.0f);
	CGFloat buttonWidth = (area.size.width - ((buttonsPerRow -1) * 8.0f)) / buttonsPerRow;
	CGFloat verticalIncrement = (area.size.height - BUTTON_HEIGHT) / (numberOfButtons - 1);
		
	int row, btn, btnCount = 0;
	for (row = 0; row < numberOfRows; row++) {
		for (btn = 0; btn < buttonsPerRow; btn++) {
			if (!row && !btn) btn = startPosition;
			
			CGFloat x = area.origin.x + area.size.width - buttonWidth - (btn * (buttonWidth + 8.0f));
			CGFloat y = area.origin.y + (btnCount * verticalIncrement);
			CGRect btnFrame = CGRectMake(x, y, buttonWidth, BUTTON_HEIGHT);
			
			UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
			[button setFrame:btnFrame];
			[button setTag:(NSInteger)btnCount];
			button.titleLabel.font = [UIFont boldSystemFontOfSize: 18];
			[button addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchDown];
			[[self view] addSubview:button];
			
			btnMap[btnCount].numer					= ratios[btnCount]->numer;
			btnMap[btnCount].denom					= ratios[btnCount]->denom;
			btnMap[btnCount].quotient				= ratios[btnCount]->quotient;
			btnMap[btnCount].pitch					= ratios[btnCount]->quotient * oneToOneFreq;
			btnMap[btnCount].tableIndicesPerSample	= btnMap[btnCount].pitch * sineTableSizeDivBySampleRate;
			btnMap[btnCount].portraitRect			= btnFrame;
			btnMap[btnCount].button					= button;
			btnMap[btnCount].label					= [[NSString stringWithFormat:@"%d%@%d", ratios[btnCount]->numer, @"/", ratios[btnCount]->denom] retain];
			[button setTitle:btnMap[btnCount].label forState:UIControlStateNormal];
			[button setTitle:btnMap[btnCount].label forState:UIControlStateHighlighted];
			[button setTitle:btnMap[btnCount].label forState:UIControlStateSelected];
			
			btnCount++;
			if (btnCount == ratioCount) break;
		}
	}
	// freeing memory used by ratios[]
	for (i = 0; i < ratioCount; i++) free(ratios[i]);
	
	upperOBPortraitRect = CGRectMake(347.0, 20.0, 100.0, 40.0);
	lowerOBPortraitRect = CGRectMake(320.0, 944.0, 100.0, 40.0);
	
	// continuing setup of btnMap[] with CGRects for landscape mode
	numberOfRows	= ROWS_IN_LANDSCAPE;
	buttonsPerRow	= LANDSCAPE_BTNSPERROW;
	startPosition	= LANDSCAPE_STARTPOS;
	
	area = CGRectMake(20.0f, 20.0f, 984.0f, 708.0f);
	buttonWidth = (area.size.width - ((buttonsPerRow -1) * 8.0f)) / buttonsPerRow;
	verticalIncrement = (area.size.height - BUTTON_HEIGHT) / (numberOfButtons - 1);
	
	btnCount = 0;
	for (row = 0; row < numberOfRows; row++) {
		for (btn = 0; btn < buttonsPerRow; btn++) {
			if (!row && !btn) btn = startPosition;
			
			CGFloat x = area.origin.x + area.size.width - buttonWidth - (btn * (buttonWidth + 8.0f));
			CGFloat y = area.origin.y + (btnCount * verticalIncrement);
			CGRect btnFrame = CGRectMake(x, y, buttonWidth, BUTTON_HEIGHT);
			btnMap[btnCount].landscapeRect = btnFrame;
			
			btnCount++;
			if (btnCount == ratioCount) break;
		}
	}
	
	upperOBLandscapeRect = CGRectMake((btnMap[104].landscapeRect.origin.x + (buttonWidth * 2.0) + 16.0), 20.0, 100.0, 40.0);
	lowerOBLandscapeRect = CGRectMake((btnMap[0].landscapeRect.origin.x - buttonWidth - 116.0), 688.0, 100.0, 40.0);
	
	[upperOptionButton setFrame:upperOBPortraitRect];
	[upperOptionButton addTarget:self action:@selector(optionPressed:) forControlEvents:UIControlEventTouchUpInside];
	[[self view] addSubview:upperOptionButton];
	[lowerOptionButton setFrame:lowerOBPortraitRect];
	[lowerOptionButton addTarget:self action:@selector(optionPressed:) forControlEvents:UIControlEventTouchUpInside];
	[[self view] addSubview:lowerOptionButton];
} // exiting -awakeFromNib

- (void) viewDidLoad {
    [super viewDidLoad];	
    [self setAudioEngine:[RKAudioEngine getSingleInstance]];
	[audioEngine setup];
	[self setSession:[AVAudioSession sharedInstance]];		// [[self session] setDelegate:self];
	NSError *setCategoryError = NULL;
	[session setCategory:AVAudioSessionCategoryAmbient error:&setCategoryError];
	NSError *setActiveError = NULL;
	[session setActive:YES error:&setActiveError];
}

- (void) viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	if (oneToOneFreq != customOneToOne->oneToOneFreq) {
		oneToOneFreq = customOneToOne->oneToOneFreq;
		for (int i = 0; i < ratioCount; i++) {
			btnMap[i].pitch = btnMap[i].quotient * oneToOneFreq;
			btnMap[i].tableIndicesPerSample	= btnMap[i].pitch * sineTableSizeDivBySampleRate;
		}
	}
	[audioEngine start];
}

 - (void) viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
}

/* - (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];	// Releases the view if it doesn't have a superview.
	// Release any cached data, images, etc that aren't in use.
 } */

- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	[audioEngine stop];
}

/* - (void) viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated]; } */

- (void)viewDidUnload {
	[super viewDidUnload];
	[audioEngine release];
	[session release];
}

- (void)dealloc {
	for (int i = 0; i < ratioCount; i++) {
		[btnMap[i].label release];
	}
    [super dealloc];
}

- (void) buttonPressed:(id)sender {
	tag   = [sender tag];
	newTN = [audioEngine newTrackNote];
	newTN->tableIndicesPerSamp = btnMap[tag].tableIndicesPerSample;
	newTN->remainingSamples[0] = (int)(SAMPLE_RATE * durationSettings->attackDuration );
	newTN->remainingSamples[1] = (int)(SAMPLE_RATE * durationSettings->decayDuration  );
	newTN->remainingSamples[2] = (int)(SAMPLE_RATE * durationSettings->sustainDuration);
	newTN->remainingSamples[3] = (int)(SAMPLE_RATE * durationSettings->releaseDuration);
	newTN->attackInitialVol = volumeSettings->attackInitialVolume;
	newTN->attackDecayBndryVol = volumeSettings->attackDecayBndryVol;
	newTN->changeInVolPerSamp[0] = (volumeSettings->attackDecayBndryVol    - volumeSettings->attackInitialVolume)  / newTN->remainingSamples[0];
	newTN->changeInVolPerSamp[1] = (volumeSettings->decaySustainBndryVol   - volumeSettings->attackDecayBndryVol)  / newTN->remainingSamples[1];
	newTN->changeInVolPerSamp[2] = (volumeSettings->sustainReleaseBndryVol - volumeSettings->decaySustainBndryVol) / newTN->remainingSamples[2];
	newTN->changeInVolPerSamp[3] = (0.0f - volumeSettings->sustainReleaseBndryVol) / newTN->remainingSamples[3];
	newTN->stage = 0;

	[audioEngine setTNAsNewNote:newTN];
}

- (void) optionPressed:(id)sender {
	if (![self modalVC]) [self setModalVC:[[RKModalVC alloc] initWithNibName:@"ModalVC" bundle:nil]];
	[self presentModalViewController:modalVC animated:YES];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation duration:(NSTimeInterval)duration {
	int count = 0;
	if ((interfaceOrientation == UIInterfaceOrientationPortrait) || (interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown)) {
		for (; count < NUMBER_OF_BUTTONS; count++) {
			[btnMap[count].button setFrame:btnMap[count].portraitRect];
		}
		[upperOptionButton setFrame:upperOBPortraitRect];
		[lowerOptionButton setFrame:lowerOBPortraitRect];
	}
	else if ((interfaceOrientation == UIInterfaceOrientationLandscapeLeft) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight)) {
		for (; count < NUMBER_OF_BUTTONS; count++) {
			[btnMap[count].button setFrame:btnMap[count].landscapeRect];
		}
		[upperOptionButton setFrame:upperOBLandscapeRect];
		[lowerOptionButton setFrame:lowerOBLandscapeRect];
	}
}

@end

