// File: RKRatio.m
// Project: RatioKey
// Copyright John Payne 2010. All rights reserved.

#import "RKRatio.h"

@implementation RKRatio

+ (struct ratio *) copyStructRatio:(struct ratio *)source to:(struct ratio *)target {
	for (int i = 0; i < NUMBER_OF_PRIMES; i++) target->pPower[i] = source->pPower[i];
	target->numer		= source->numer;
	target->denom		= source->denom;
	target->quotient	= source->quotient;
	return target;
}

+ (BOOL) setStructRatio:(struct ratio *)target fromNum:(UInt32)num andDen:(UInt32)den {
	if (num < (UInt32)1) return NO;
	if (den < (UInt32)1) return NO;
	target->numer		= num;
	target->denom		= den;
	target->quotient	= (float)num / (float)den;
	for (int i = 0; i < NUMBER_OF_PRIMES; i++) target->pPower[i] = 0;
	while (!(num % (UInt32)2) )  {target->pPower[0]++; num /=  (UInt32)2;}
	while (!(den % (UInt32)2) )  {target->pPower[0]--; den /=  (UInt32)2;}
	while (!(num % (UInt32)3) )  {target->pPower[1]++; num /=  (UInt32)3;}
	while (!(den % (UInt32)3) )  {target->pPower[1]--; den /=  (UInt32)3;}
	while (!(num % (UInt32)5) )  {target->pPower[2]++; num /=  (UInt32)5;}
	while (!(den % (UInt32)5) )  {target->pPower[2]--; den /=  (UInt32)5;}
	while (!(num % (UInt32)7) )  {target->pPower[3]++; num /=  (UInt32)7;}
	while (!(den % (UInt32)7) )  {target->pPower[3]--; den /=  (UInt32)7;}
	while (!(num % (UInt32)11))  {target->pPower[4]++; num /= (UInt32)11;}
	while (!(den % (UInt32)11))  {target->pPower[4]--; den /= (UInt32)11;}
	if ((num != (UInt32)1) || (den != (UInt32)1)) return NO;
	return YES;
}

+ (struct ratio *) fromPrimesCompleteRatio:(struct ratio *)ratio {
	int i, num = 1, den = 1;
	i = ratio->pPower[0];
	while (i > 0) { num *=  2;  i--; }
	while (i < 0) { den *=  2;  i++; }
	i = ratio->pPower[1];
	while (i > 0) { num *=  3;  i--; }
	while (i < 0) { den *=  3;  i++; }
	i = ratio->pPower[2];
	while (i > 0) { num *=  5;  i--; }
	while (i < 0) { den *=  5;  i++; }
	i = ratio->pPower[3];
	while (i > 0) { num *=  7;  i--; }
	while (i < 0) { den *=  7;  i++; }
	i = ratio->pPower[4];
	while (i > 0) { num *= 11;  i--; }
	while (i < 0) { den *= 11;  i++; }
	ratio->numer		= (UInt32)num;
	ratio->denom		= (UInt32)den;
	ratio->quotient	= (float)num / (float)den;
	return ratio;
}

+ (struct ratio *) unifyStructRatio:(struct ratio *)thisOne {
	for (int i = 0; i < NUMBER_OF_PRIMES; i++) thisOne->pPower[i] = 0;
	thisOne->numer		= (UInt32)1;
	thisOne->denom		= (UInt32)1;
	thisOne->quotient	= 1.0f;
	return thisOne;
}

@end
